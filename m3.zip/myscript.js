
function useridTest(uid, min, max) {
    var uidLen = uid.length;
    if (uidLen == 0 || uidLen < min || uidLen > max) {
        return false;
    }
}
function passwordTest(pass, min, max) {
    var passLen = pass.length;
    if (passLen == 0 || passLen < min || passLen > max) {
        return false;
    }

}
function nameTest(text) {
    var letters = /^[A-Za-z]+$/;
    if (letters.test(text) == false) {
        return false;
    }
}
function validateEmail(frm) {
    var reg = /^([A-Za-z0-9_\-\.])+\@([A-Za-z0-9_\-\.])+\.([A-Za-z]{2,4})$/;
    var address = frm;
    if (reg.test(address) == false) {
        return false;
    }
    else {
        return true;
    }
}

function countryselect(country) {
    if (country == "Default") {
        return false;
    }
    else {
        return true;
    }
}

function validsex(umsex) {
    if(umsex != "male" || umsex != "female"){
        return true;
    }else{
        return false;
    }
}
function validateForm() {
    var user = frm.userid.value;
    var pword = frm.password.value;
    var name = frm.name.value;
    var address = frm.address.value;
    var country = frm.Country.value;
    var zip = frm.zipcode.value;
    var email = frm.email.value;
    var usex = frm.elements['sex'].value;

    var a = true;
    var b = true;
    var c = true;
    var d = true;
    var e = true;
    var f = true;
    var g = true;

    if (user == "" || pword == "" || name == "" || email == "") {
        alert("There are empty fields, please fill them");
        a = false;
    }
    if (useridTest(user, 3, 12) == false) {
        alert("Userid must be between 3 to 12");
        b = false;
    }

    if (passwordTest(pword, 7, 12) == false) {
        alert("Password must be between 7 to 12");
        c = false;
    }
    if (nameTest(name) == false) {
        alert("Only alphabetic letters");
        d = false;
    }
    if (validateEmail(email) == false) {
        alert("invalid e mail address ");
        e = false;
    }
    if (countryselect(country) == false) {
        alert("Please select the country ");
        f = false;
    }
    if (validsex(usex) == false) {
        alert("Please select the Gender ");
        g = false;
    }
    if(a && b && c && d && e && f && g){
        alert("Form Submitted Successfully");
    }else{
        alert("Try again");
    }
}